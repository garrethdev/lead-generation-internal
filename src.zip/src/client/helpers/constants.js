export const MAILCHIP_API_KEY = 'a25f82c562f5b7c18ec76f0ce0adabef-us20';
export const mailchimpUrl = 'https://us20.api.mailchimp.com/3.0';
export const LIST_ID = 'a2781f9374';
