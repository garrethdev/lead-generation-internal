export default {
  PRIMARY_COLOR: 'green',
  SECONDARY_COLOR: 'black',
  FONT_COLOR: 'red',
  MEDIATORY_COLOR: 'orange'
};